document.addEventListener("DOMContentLoaded", function () {
    let progressBar = document.getElementById("progressBar");
    let width = 0;
    let interval = setInterval(() => {
        if (width >= 100) {
            clearInterval(interval);
        } else {
            width += 1;
            progressBar.style.width = width + "%";
        }
    }, 100);
});
